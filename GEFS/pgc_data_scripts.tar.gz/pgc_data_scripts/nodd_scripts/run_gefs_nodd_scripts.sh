#!/bin/bash
#PBS -N run_gefs_nodd_scripts
#PBS -j oe
#PBS -o /lfs/h2/emc/vpppg/noscrub/shannon.shields/pgc_data_scripts/nodd_scripts/log_gefs_pgc_data_20210103_out.txt
#PBS -q "dev_transfer"
#PBS -A VERF-DEV
#PBS -l walltime=02:00:00
#PBS -l select=1:ncpus=1:mem=50GB
#PBS -l debug=true

set -x

export STARTDATE=20210103
export ENDDATE=20210104 #Not inclusive

. /lfs/h2/emc/vpppg/noscrub/shannon.shields/pgc_data_scripts/nodd_scripts/nodd_wrapper.sh $STARTDATE $ENDDATE
