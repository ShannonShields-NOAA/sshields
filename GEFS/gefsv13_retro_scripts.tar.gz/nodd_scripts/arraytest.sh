
# It turns out wildcards (*) are not support for wget. So you will need to do several nested loops and arrays.

# wget command example
#wget https://noaa-gefs-pds.s3.amazonaws.com/gefs.YYYYMMDD/CC/atmos/pgrb2ap5/gep${member}.t${cyc}z.pgrb2a.0p50.f${flead}
echo $(date)

url="https://noaa-gefs-pds.s3.amazonaws.com"
dest="/lfs/h2/emc/vpppg/noscrub/shannon.shields/gefsv13_retro/nodd_output"
PDY=$1
date_switch=20200922
if [[ "$PDY" > "$date_switch" ]]; then
    memberarr="01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30"
else
    memberarr="01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20"
fi
cyclearr="00"
forecastleadarr="000 006 012 018 024 030 036 042 048 054 060 066 072 078 084 090 096 102 108 114 120 126 132 138 144 150 156 162 168 174 180 186 192 198 204 210 216 222 228 234 240 246 252 258 264 270 276 282 288 294 300 306 312 318 324 330 336 342 348 354 360 366 372 378 384 390 396 402 408 414 420 426 432 438 444 450 456 462 468 474 480 486 492 498 504 510 516 522 528 534 540 546 552 558 564 570 576 582 588 594 600 606 612 618 624 630 636 642 648 654 660 666 672 678 684 690 696 702 708 714 720 726 732 738 744 750 756 762 768 774 780 786 792 798 804 810 816 822 828 834 840"

for cyc in ${cyclearr[@]}
do
  for mem in ${memberarr[@]}
  do
    for flead in ${forecastleadarr[@]}
    do	    
      echo $cyc
      echo $mem
      echo $flead
      if [ ! -d $dest/gefs.${PDY}/${cyc}/atmos ]; then
          mkdir -p $dest/gefs.${PDY}/${cyc}/atmos
      fi
      if [[ "$PDY" > "$date_switch" ]]; then
          file_a_name=gep${mem}.t${cyc}z.pgrb2a.0p50.f${flead}
	  file_b_name=gep${mem}.t${cyc}z.pgrb2b.0p50.f${flead}
      else
          file_name=gep${mem}.t${cyc}z.pgrb2af${flead}
      fi
      echo "wget -O $dest/gefs.${PDY}/${cyc}/atmos/${file_a_name} $url/gefs.${PDY}/${cyc}/atmos/pgrb2ap5/${file_a_name}"
      wget -O $dest/gefs.${PDY}/${cyc}/atmos/${file_a_name} $url/gefs.${PDY}/${cyc}/atmos/pgrb2ap5/${file_a_name} -q -o /dev/null
      echo "wget -O $dest/gefs.${PDY}/${cyc}/atmos/${file_b_name} $url/gefs.${PDY}/${cyc}/atmos/pgrb2bp5/${file_b_name}"
      wget -O $dest/gefs.${PDY}/${cyc}/atmos/${file_b_name} $url/gefs.${PDY}/${cyc}/atmos/pgrb2bp5/${file_b_name} -q -o /dev/null
    done  
  done
done

echo $(date)
