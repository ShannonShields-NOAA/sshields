#!/bin/bash
#PBS -N run_gefs_missing
#PBS -j oe
#PBS -o /lfs/h2/emc/vpppg/noscrub/shannon.shields/gefs_missing_data/scripts/log_gefs_missing_data_20220506_out.txt
#PBS -q "dev_transfer"
#PBS -A VERF-DEV
#PBS -l walltime=02:00:00
#PBS -l select=1:ncpus=1:mem=50GB
#PBS -l debug=true

set -x

export STARTDATE=20220506
export ENDDATE=20220507 #Not inclusive

. /lfs/h2/emc/vpppg/noscrub/shannon.shields/gefs_missing_data/scripts/nodd_wrapper.sh $STARTDATE $ENDDATE
