#!/bin/bash
#PBS -N run_gefs_missing_20members
#PBS -j oe
#PBS -o /lfs/h2/emc/vpppg/noscrub/shannon.shields/gefs_missing_data/scripts/log_gefs_missing_data_20members_20191226_out.txt
#PBS -q "dev_transfer"
#PBS -A VERF-DEV
#PBS -l walltime=06:00:00
#PBS -l select=1:ncpus=1:mem=50GB
#PBS -l debug=true

set -x

export STARTDATE=20191226
export ENDDATE=20200102 #Not inclusive

. /lfs/h2/emc/vpppg/noscrub/shannon.shields/gefs_missing_data/scripts/nodd_wrapper_20members.sh $STARTDATE $ENDDATE
