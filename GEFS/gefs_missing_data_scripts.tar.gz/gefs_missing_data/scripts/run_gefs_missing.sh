#!/bin/bash
#PBS -N run_gefs_missing
#PBS -j oe
#PBS -o /lfs/h2/emc/vpppg/noscrub/shannon.shields/gefs_missing_data/scripts/log_gefs_missing_data_20230627_out.txt
#PBS -q "dev_transfer"
#PBS -A VERF-DEV
#PBS -l walltime=06:00:00
#PBS -l select=1:ncpus=1:mem=50GB
#PBS -l debug=true

set -x

export STARTDATE=20230627
export ENDDATE=20230701 #Not inclusive

. /lfs/h2/emc/vpppg/noscrub/shannon.shields/gefs_missing_data/scripts/nodd_wrapper.sh $STARTDATE $ENDDATE
