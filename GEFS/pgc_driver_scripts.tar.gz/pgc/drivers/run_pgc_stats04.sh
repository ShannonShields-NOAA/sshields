#!/bin/bash -l

rundate=20190411
enddate=20190420

rundir=/lfs/h2/emc/vpppg/noscrub/${USER}/pgc/drivers
mkdir -p $rundir
cd $rundir

while [[ "$rundate" -le "$enddate" ]]; do
  echo $rundate
  if [ -s pgc_stats_grid2grid.${rundate}.sh ]; then
     rm -f pgc_stats_grid2grid.${rundate}.sh
  fi
  if [ -s pgc_stats_grid2obs.${rundate}.sh ]; then
     rm -f pgc_stats_grid2obs.${rundate}.sh
  fi
  if [ -s pgc_stats_precip.${rundate}.sh ]; then
     rm -f pgc_stats_precip.${rundate}.sh
  fi

# create grid2grid job card ##########################################
touch pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -N jevs_global_ens_gefs_atmos_grid2grid_stats' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -j oe' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -S /bin/bash' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -q dev' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -A VERF-DEV' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -l walltime=02:00:00' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -l place=vscatter,select=1:ncpus=4:mem=100GB' >> pgc_stats_grid2grid.${rundate}.sh
echo '#PBS -l debug=true' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'set -x' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo export PDY=${rundate} >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export OMP_NUM_THREADS=1' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export HOMEevs=/lfs/h2/emc/vpppg/noscrub/${USER}/feature_WPC_PGC_GEFS/EVS' >> pgc_stats_grid2grid.${rundate}.sh
echo 'source $HOMEevs/versions/run.ver' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export envir=prod' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export NET=evs' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export RUN=atmos' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export STEP=stats' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export COMPONENT=global_ens' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export VERIF_CASE=grid2grid' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export MODELNAME=gefs' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'module reset' >> pgc_stats_grid2grid.${rundate}.sh
echo 'module load prod_envir/${prod_envir_ver}' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'source $HOMEevs/dev/modulefiles/$COMPONENT/${COMPONENT}_${STEP}.sh' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'evs_ver_2d=$(echo $evs_ver | cut -d"." -f1-2)' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export KEEPDATA=YES' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export vhr=00' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export COMIN=/lfs/h2/emc/vpppg/noscrub/shelley.melchior/wpc_pgc/$NET/$evs_ver_2d' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export COMOUT=/lfs/h2/emc/vpppg/noscrub/${USER}/wpc_pgc/$NET/$evs_ver_2d' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export FIXevs=/lfs/h2/emc/vpppg/noscrub/emc.vpppg/verification/EVS_fix' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export DATAROOT=/lfs/h2/emc/stmp/${USER}/evs_test/$envir/tmp' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export job=${PBS_JOBNAME:-jevs_${MODELNAME}_${VERIF_CASE}_${STEP}}' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export jobid=$job.${PBS_JOBID:-$$}' >> pgc_stats_grid2grid.${rundate}.sh
echo '#export SENDMAIL=YES' >> pgc_stats_grid2grid.${rundate}.sh
echo 'export MAILTO="shannon.shields@noaa.gov"' >> pgc_stats_grid2grid.${rundate}.sh
echo ' ' >> pgc_stats_grid2grid.${rundate}.sh
echo '${HOMEevs}/jobs/JEVS_GLOBAL_ENS_STATS' >> pgc_stats_grid2grid.${rundate}.sh
######################################################################

# create grid2obs job card ###########################################
touch pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -N jevs_global_ens_gefs_atmos_grid2obs_stats' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -j oe' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -S /bin/bash' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -q dev' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -A VERF-DEV' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -l walltime=02:30:00' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -l place=vscatter,select=1:ncpus=60:mem=100GB' >> pgc_stats_grid2obs.${rundate}.sh
echo '#PBS -l debug=true' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'set -x' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo export PDY=${rundate} >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export HOMEevs=/lfs/h2/emc/vpppg/noscrub/${USER}/feature_WPC_PGC_GEFS/EVS' >> pgc_stats_grid2obs.${rundate}.sh
echo 'source $HOMEevs/versions/run.ver' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export envir=prod' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export NET=evs' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export RUN=atmos' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export STEP=stats' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export COMPONENT=global_ens' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export VERIF_CASE=grid2obs' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export MODELNAME=gefs' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'module reset' >> pgc_stats_grid2obs.${rundate}.sh
echo 'module load prod_envir/${prod_envir_ver}' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'source $HOMEevs/dev/modulefiles/$COMPONENT/${COMPONENT}_${STEP}.sh' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'evs_ver_2d=$(echo $evs_ver | cut -d"." -f1-2)' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export KEEPDATA=YES' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export vhr=00' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export COMIN=/lfs/h2/emc/vpppg/noscrub/shelley.melchior/wpc_pgc/$NET/$evs_ver_2d' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export COMOUT=/lfs/h2/emc/vpppg/noscrub/${USER}/wpc_pgc/$NET/$evs_ver_2d' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export FIXevs=/lfs/h2/emc/vpppg/noscrub/emc.vpppg/verification/EVS_fix' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export DATAROOT=/lfs/h2/emc/stmp/${USER}/evs_test/$envir/tmp' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export job=${PBS_JOBNAME:-jevs_${MODELNAME}_${VERIF_CASE}_${STEP}}' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export jobid=$job.${PBS_JOBID:-$$}' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export OMP_NUM_THREADS=1' >> pgc_stats_grid2obs.${rundate}.sh
echo '#export SENDMAIL=YES' >> pgc_stats_grid2obs.${rundate}.sh
echo 'export MAILTO="shannon.shields@noaa.gov"' >> pgc_stats_grid2obs.${rundate}.sh
echo ' ' >> pgc_stats_grid2obs.${rundate}.sh
echo '${HOMEevs}/jobs/JEVS_GLOBAL_ENS_STATS' >> pgc_stats_grid2obs.${rundate}.sh
######################################################################

# create precip job card #############################################
touch pgc_stats_precip.${rundate}.sh
echo '#PBS -N jevs_global_ens_gefs_atmos_precip_stats' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -j oe' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -S /bin/bash' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -q dev' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -A VERF-DEV' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -l walltime=00:30:00' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -l place=vscatter,select=1:ncpus=5:mem=50GB' >> pgc_stats_precip.${rundate}.sh
echo '#PBS -l debug=true' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'set -x' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo export PDY=${rundate} >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'export OMP_NUM_THREADS=1' >> pgc_stats_precip.${rundate}.sh
echo 'export HOMEevs=/lfs/h2/emc/vpppg/noscrub/${USER}/feature_WPC_PGC_GEFS/EVS' >> pgc_stats_precip.${rundate}.sh
echo 'source $HOMEevs/versions/run.ver' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'export envir=prod' >> pgc_stats_precip.${rundate}.sh
echo 'export NET=evs' >> pgc_stats_precip.${rundate}.sh
echo 'export RUN=atmos' >> pgc_stats_precip.${rundate}.sh
echo 'export STEP=stats' >> pgc_stats_precip.${rundate}.sh
echo 'export COMPONENT=global_ens' >> pgc_stats_precip.${rundate}.sh
echo 'export VERIF_CASE=precip' >> pgc_stats_precip.${rundate}.sh
echo 'export MODELNAME=gefs' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'module reset' >> pgc_stats_precip.${rundate}.sh
echo 'module load prod_envir/${prod_envir_ver}' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'source $HOMEevs/dev/modulefiles/$COMPONENT/${COMPONENT}_${STEP}.sh' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'evs_ver_2d=$(echo $evs_ver | cut -d"." -f1-2)' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'export KEEPDATA=YES' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo 'export vhr=00' >> pgc_stats_precip.${rundate}.sh
echo 'export COMIN=/lfs/h2/emc/vpppg/noscrub/shelley.melchior/wpc_pgc/$NET/$evs_ver_2d' >> pgc_stats_precip.${rundate}.sh
echo 'export COMOUT=/lfs/h2/emc/vpppg/noscrub/${USER}/wpc_pgc/$NET/$evs_ver_2d' >> pgc_stats_precip.${rundate}.sh
echo 'export FIXevs=/lfs/h2/emc/vpppg/noscrub/emc.vpppg/verification/EVS_fix' >> pgc_stats_precip.${rundate}.sh
echo 'export DATAROOT=/lfs/h2/emc/stmp/${USER}/evs_test/$envir/tmp' >> pgc_stats_precip.${rundate}.sh
echo 'export job=${PBS_JOBNAME:-jevs_${MODELNAME}_${VERIF_CASE}_${STEP}}' >> pgc_stats_precip.${rundate}.sh
echo 'export jobid=$job.${PBS_JOBID:-$$}' >> pgc_stats_precip.${rundate}.sh
echo '#export SENDMAIL=YES' >> pgc_stats_precip.${rundate}.sh
echo 'export MAILTO="shannon.shields@noaa.gov"' >> pgc_stats_precip.${rundate}.sh
echo ' ' >> pgc_stats_precip.${rundate}.sh
echo '${HOMEevs}/jobs/JEVS_GLOBAL_ENS_STATS' >> pgc_stats_precip.${rundate}.sh
######################################################################

  qsub pgc_stats_grid2grid.${rundate}.sh
  qsub pgc_stats_grid2obs.${rundate}.sh
  qsub pgc_stats_precip.${rundate}.sh
  sleep 16m

  rundate=$(date --date "$rundate + 1 day" +"%Y%m%d")
done

exit
