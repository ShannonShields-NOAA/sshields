#!/bin/bash
#SBATCH --account=ovp
#SBATCH --job-name=htar_cfs
#SBATCH --output=/scratch2/NCEPDEV/stmp1/Shannon.Shields/scripts/s2s/cases/sbatch_out/htar_cfs.%j.out
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=2:00:00
#SBATCH --partition=service

set -x

# ~~~~~~~
# 1) Set 'cfsdir' to cfs root directory on HPSS (path is continued later) and 'savedir' to preferred directory for data storage
# 2) Set cfstimefcst to true or false. If false, will check settings for downloading monthly average forecast files and download them (versus hourly/instantaneous, i.e., 'time')
# 3) Set YEARR, MONTHH, DAYY, and HOWR to list of desired initialization times and FYM to list of desired forecast year-months (space-separated lists)
# 4) Set tarpaths and files depending on current locations (e.g., 'cfsanltarpath'). Note if statement directs bash reader to one of two options, determined by cfstimefcst
# 5) Comment/Uncomment htar statements depending on what you'd like to download (analyses, forecasts, or both)
# 6) Adjust SBATCH settings above ('account', 'job-name', 'output', and/or 'time' options particularly)
# 7) Save, exit, and run this on the command line as follows: ~ $ sbatch htar_cfs.sh
# ~~~~~~~

cfsdir=${cfsdir:-/NCEPPROD/hpssprod/runhistory}
savedir=${savedir:-/scratch2/NCEPDEV/stmp1/Shannon.Shields/scripts/s2s_data}
cfstimefcst=true

for YEARR in 2023 
do
   for MONTHH in 04 #02 03 04 05 06 07 08 09 10 11
   do
      for DAYY in 09 
      do
         for HOWR in 00
         do
            cfsanltarpath="${cfsdir}/cfs${YEARR}/${YEARR}${MONTHH}/monthly_analysis/cfs.pgb.${YEARR}${MONTHH}.monthly.tar"
            cfsanltarpath2="${cfsdir}/cfs${YEARR}/${YEARR}${MONTHH}/${YEARR}${MONTHH}${DAYY}/Analysis/cfs.pgrbh.${YEARR}${MONTHH}${DAYY}.tar"
            cfsanlfile="pgbhnl.gdas.${YEARR}${MONTHH}.grib2"
            cfsanlfile2="cdas1.t${HOWR}z.pgrbhanl.grib2"
            #cfstarpath="${cfsdir}/cfs${YEARR}/${YEARR}${MONTHH}/${YEARR}${MONTHH}${DAYY}/monthly/cfs.pgbf.${YEARR}${MONTHH}${DAYY}${HOWR}.m01.monthly.tar"
            cfstarpath="${cfsdir}/cfs${YEARR}/${YEARR}${MONTHH}/${YEARR}${MONTHH}${DAYY}/monthly/cfs.pgbf.${YEARR}${MONTHH}${DAYY}${HOWR}.m01.monthly.tar"
            #cfstarpath2="${cfsdir}/cfs${YEARR}/${YEARR}${MONTHH}/${YEARR}${MONTHH}${DAYY}/time/cfs.${YEARR}${MONTHH}${DAYY}${HOWR}.m01.time.tar"
            cfstarpath2="${cfsdir}/cfs${YEARR}/${YEARR}${MONTHH}/${YEARR}${MONTHH}${DAYY}/6hourly/cfs.flxf.${YEARR}${MONTHH}${DAYY}${HOWR}.m01.6hourly.tar"
            if [ "$cfstimefcst" = true ] ; then
               #htar -xvf ${cfsanltarpath2} ${cfsanlfile2}; mkdir -p ${savedir}/cfs.${YEARR}${MONTHH}/${DAYY}; mv ${cfsanlfile2} ${savedir}/cfs.${YEARR}${MONTHH}/${DAYY}/.
               for varbl in flxf #t850
               do
                  cfsfile="${varbl}2023040900.01.${YEARR}${MONTHH}${DAYY}${HOWR}.grb2"
                  htar -xvf ${cfstarpath2} ${cfsfile}; mkdir -p ${savedir}/cfs.${YEARR}${MONTHH}/${DAYY}; mv ${cfsfile} ${savedir}/cfs.${YEARR}${MONTHH}/${DAYY}/.
                  wait
               done
            else
               #htar -xvf ${cfsanltarpath} ${cfsanlfile}; mkdir -p ${savedir}/cfs.${YEARR}${MONTHH}/; mv ${cfsanlfile} ${savedir}/cfs.${YEARR}${MONTHH}/.
               for FYM in 202208 #202102 202103 202104 202105 202106 202107 202108 202109 202110 
               do
                  #cfsfile="pgbf.01.${YEARR}${MONTHH}${DAYY}${HOWR}.${FYM}.avrg.grib.${HOWR}Z.grb2"
                  cfsfile="pgbf.01.${YEARR}${MONTHH}${DAYY}${HOWR}.${FYM}.avrg.grib.grb2"
                  #htar -xvf ${cfstarpath} ${cfsfile}; mkdir -p ${savedir}/cfs.${YEARR}${MONTHH}/${DAYY}; mv ${cfsfile} ${savedir}/cfs.${YEARR}${MONTHH}/${DAYY}/.
                  wait
               done
            fi
         done
      done
   done
done
