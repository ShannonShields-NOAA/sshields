#!/bin/bash 
#SBATCH --account=ovp
#SBATCH --job=htar_gefs
#SBATCH --output=/scratch2/NCEPDEV/stmp1/Shannon.Shields/scripts/s2s/cases/sbatch_out/htar_gefs.%j.out
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=2:00:00
#SBATCH --partition=service

set -x

# ~~~~~~~
# 1) Set 'gefsdir' to gefs root directory on HPSS (path is continued later) and 'savedir' to preferred directory for data storage. Note that 'rh%Y/%Y%m' should normally be included in gefsdir
# 2) Set DAYT and HOWR to list of desired initialization dates and times, respectively, FF to list of desired forecast hours, and PP to list of desired ensemble members (space-separated lists)
# 3) Set tarpaths and files depending on current locations (e.g., 'gefsanltarpath'). Set 00-05/06-11/12-17/18-23 as RAP valid time. 
# 4) Comment/Uncomment htar statements depending on what you'd like to download (0p25/0p50 files, gefs spread/control/mean/gfs/member, CONUS/NA RAP)
# 5) Adjust SBATCH settings above ('account', 'job', 'output', and/or 'time' options particularly)
# 6) Save, exit, and run this on the command line as follows: ~ $ sbatch htar_gefs.sh
# ~~~~~~~

savedir=${savedir:-/scratch2/NCEPDEV/stmp1/Shannon.Shields/scripts/s2s_data}
gefsdir=${gefsdir:-/NCEPPROD/2year/hpssprod/runhistory/rh2024/202402}
#gefsdir=${gefsdir:-/NCEPPROD/hpssprod/runhistory/5year/rh2021/202106} #grb2sp25
rapdir=${rapdir:-/NCEPPROD/hpssprod/runhistory/2year/rh2022/202207}
gfsdir=${gfsdir:-/NCEPPROD/hpssprod/runhistory/rh2023/202309}

for DAYT in 20240202 #20220810 20220811 20220812 20220813 20220814 20220815 20220816 20220817 20220818 20220819 20220820 20220821 20220822 20220823 20220824 20220825 20220826 20220827 20220828 20220829 20220830 20220831 
do
   for HOWR in 12 
   do
      gefstarpath="${gefsdir}/${DAYT}/com_gefs_v12.3_gefs.${DAYT}_${HOWR}.atmos_pgrb2ap5.tar"
      #gefstarpath="${gefsdir}/${DAYT}/com_gefs_prod_gefs.${DAYT}_${HOWR}.atmos_pgrb2sp25.tar"
      #raptarpath="${rapdir}/${DAYT}/com_rap_prod_rap.${DAYT}12-17.awp130.tar"
      raptarpath="${rapdir}/${DAYT}/com_rap_v5.1_rap.${DAYT}18-23.awip32.tar"
      gfstarpath="${gfsdir}/${DAYT}/com_gfs_v16.3_gfs.${DAYT}_${HOWR}.gfs_pgrb2.tar"
      for FF in 504 516 528 540 552 564 576 588 600 612 624 636 648 660 672 #165 189 213 237 261
      do
         #gefsspreadfile="atmos/pgrb2ap5/gespr.t${HOWR}z.pgrb2a.0p50.f${FF}"
         #gefscontrolfile="atmos/pgrb2ap5/gec00.t${HOWR}z.pgrb2a.0p50.f${FF}"
         gefsmeanfile="atmos/pgrb2ap5/geavg.t${HOWR}z.pgrb2a.0p50.f${FF}"
         gefsgfsfile="atmos/pgrb2ap5/gegfs.t${HOWR}z.pgrb2a.0p50.f000"
         #gefsspreadfile="atmos/pgrb2sp25/gespr.t${HOWR}z.pgrb2s.0p25.f${FF}"
         #gefscontrolfile="atmos/pgrb2sp25/gec00.t${HOWR}z.pgrb2s.0p25.f${FF}"
         #gefsmeanfile="atmos/pgrb2sp25/geavg.t${HOWR}z.pgrb2s.0p25.f${FF}"
         #gefsgfsfile="atmos/pgrb2sp25/gegfs.t${HOWR}z.pgrb2s.0p25.f${FF}"
         #rapfile="rap.t${HOWR}z.awp130pgrbf00.grib2"
         rapfile="rap.t${HOWR}z.awip32f00.grib2"
         gfsfile="gfs.${DAYT}/${HOWR}/atmos/gfs.t${HOWR}z.pgrb2.0p50.f000"
         #htar -xvf ${gefstarpath} ./${gefsspreadfile}; mkdir ${savedir}/gefs.${DAYT}; mv ${gefsspreadfile} ${savedir}/gefs.${DAYT}/.
         #htar -xvf ${gefstarpath} ./${gefscontrolfile}; mkdir ${savedir}/gefs.${DAYT}; mv ${gefscontrolfile} ${savedir}/gefs.${DAYT}/.
         htar -xvf ${gefstarpath} ./${gefsmeanfile}; mkdir ${savedir}/gefs.${DAYT}; mv ${gefsmeanfile} ${savedir}/gefs.${DAYT}/.
         #htar -xvf ${gefstarpath} ./${gefsgfsfile}; mkdir ${savedir}/gefs.${DAYT}; mv ${gefsgfsfile} ${savedir}/gefs.${DAYT}/.
         #htar -xvf ${raptarpath} ./${rapfile}; mkdir ${savedir}/rap.${DAYT}; mv ${rapfile} ${savedir}/rap.${DAYT}/.
         #htar -xvf ${gfstarpath} ./${gfsfile}; mkdir ${savedir}/gfs.${DAYT}; mv ${gfsfile} ${savedir}/gfs.${DAYT}/.
         for PP in 30 #01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
         do
            gefsmemfile="atmos/pgrb2bp5/gep${PP}.t${HOWR}z.pgrb2b.0p50.f${FF}"
            #gefsmemfile="atmos/pgrb2sp25/gep${PP}.t${HOWR}z.pgrb2s.0p25.f${FF}"
            #htar -xvf ${gefstarpath} ./${gefsmemfile}; mkdir ${savedir}/gefs.${DAYT}; mv ${gefsmemfile} ${savedir}/gefs.${DAYT}/.
         done 
         wait
      done
   done
done
